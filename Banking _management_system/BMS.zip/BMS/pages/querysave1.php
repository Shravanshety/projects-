
<?php
    $accno = $_POST['acc_no'];
   
$query = $_POST['query'];

$dsn = 'mysql:host=localhost;dbname=bank';
$username = 'root';
$password = '';

try {
    $con = new PDO($dsn, $username, $password);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO queries (accno,context) VALUES (?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->execute([$accno, $query]);
    echo "<br><center><b>your Issue is recorded .it wil be resolved shortly....! !";
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

?>


                
                
           
              
                
            




?>
 </body>
</html> 
 





















 
 
