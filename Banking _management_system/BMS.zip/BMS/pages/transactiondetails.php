<html>
    <head>
        <style>
            nav{
                position:absolute;
                top:50px;
                left:10px;
                padding:10px;
                background-color:rgb(205, 235, 235);
                width:97%;
                height: 20px;
                border:2px black;
                border-radius:2px;
                box-shadow:0px 0px 2px 0px  ;
                color:rgb(22, 22, 23);
                margin-right:20px;
                
                

            }
            a{
                padding: 10px;
                margin-left: 20px;
                text-decoration: none;
                float:sticky;
            }

            a:hover{
                cursor: pointer;
                background-color:rgb(45, 43, 44);
                color:white;
                
            }
             
            a:active{
                margin-bottom:10px;
            }


            img{
                position:relative;
                top:30px;
            }
            
            input{
                border-radius: 5px;
            }
            table {
                position:absolute;
                top:150px;
                left:450px;
            border: 3px solid rgb(210, 211, 212);
            border-radius: 10px;
            width: auto;
            height: auto;
            box-shadow: 0 0 30px rgb(199, 199, 230);
            padding: 20px;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background-color: white;
        }
        th {
            border: 2px solid black;
            border-radius: 10px;
            background-color: powderblue;
            padding: 10px;
        }
        td {
            border: 2px;
            border-radius: 2px;
            background-color: lightblue;
            padding: 10px;
        }
       </style>
    </head>
    <body>
        
        <h1><center><b> BMS BANK</b> </center></h1>
        
        <nav>
        <a href="usermain.html" >HOME</a> 
            <a href="Account.html" >Account</a> 
            <a href="Deposit.html">Deposit</a>
            <a href="withdraw.html">Withdrawal</a>
            <a href="transactiondetails.php">Transactions</a>
            <a href="aboutus.html">About Us</a>
            <div style="float: right;">
                <a  href="login.html">logout</a>
            </div>
                </nav>
        <img src="OIP.jpg"  alt="bank " width="100%" height="100%" style="filter: blur(5px);" ></img>
        
        <div  class="border" >
    
            <form method="post" action="Accountsave.php">
               
                
           
                <?php
        $con = mysqli_connect("localhost", "root", "", "bank");
        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $records = mysqli_query($con, "SELECT * FROM transactions");
        ?>
        <div class="border">
        
            
                <table>
                    <tr>
                        <th>Id</th>
                        <th>Account No</th>
                        <th>Transaction</th>
                        <th>Amount</th>
                        <th>Balance</th>
                    </tr>
                    <?php
                    while ($row = mysqli_fetch_array($records)) {
                        echo "<tr><td>" . $row['transactionid'] . "</td><td>" . $row['accno'] . "</td><td>" . $row['transaction_type'] . "</td><td>" . $row['amount'] . "</td><td>" . $row['Balance'] . "</td></tr>";
                    }
                    mysqli_close($con);
                    ?>

            






    </body>
</html> 
 





















 
 
