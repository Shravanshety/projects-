<html>
    <head>
        <style>
            nav{
                position:absolute;
                top:50px;
                left:10px;
                padding:10px;
                background-color:rgb(205, 235, 235);
                width:97%;
                height: 20px;
                border:2px black;
                border-radius:2px;
                box-shadow:0px 0px 2px 0px  ;
                color:rgb(22, 22, 23);
                margin-right:20px;
                
                

            }
            a{
                padding: 10px;
                margin-left: 20px;
                text-decoration: none;
                float:sticky;
            }

            a:hover{
                cursor: pointer;
                background-color:rgb(45, 43, 44);
                color:white;
                
            }
             
            a:active{
                margin-bottom:10px;
            }


            img{
                position:relative;
                top:30px;
            }
            .border{
                align-content:center;
                position:absolute;
                top:150px;
                left:450px;
                padding:20px;
                border: 4px green solid;
                border-radius: 5px;
                }
            input{
                border-radius: 5px;
            }
       </style>
    </head>
    <body>
        
        <h1><center><b> BMS BANK</b> </center></h1>
        
        <nav>
            <a href="usermain.html" >HOME</a> 
            <a href="Account.html" >Account</a> 
            <a href="Deposit.html">Deposit</a>
            <a href="withdraw.html">withdrawal</a>
            <a href="transactiondetails.php">Transactions</a>
            <div style="float: right;">
                <a  href="">logout</a>
            </div>
                </nav>
        <img src="OIP.jpg"  alt="bank " width="100%" height="100%" style="filter: blur(5px);" ></img>
        
        <div  class="border" >
    <?php
    $accno = $_POST['acc_no'];
   $accname = $_POST['a_name'];
   $acctype = $_POST['acctype'];
$balance = $_POST['balance'];
$email = $_POST['email'];
$mobileno = $_POST['acc_mob'];

$dsn = 'mysql:host=localhost;dbname=bank';
$username = 'root';
$password = '';

try {
    $con = new PDO($dsn, $username, $password);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO accounts (accno,accname,acctype,balance,email,mobileno) VALUES (?, ?, ?, ?, ? ,?)";
    $stmt = $con->prepare($sql);
    $stmt->execute([$accno, $accname, $acctype, $balance,$email,$mobileno]);
    echo "<br><center><b>New Account  $accname created  Successful....!";
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

?>


                
                
           
              
                
            




?>
 </body>
</html> 
 





















 
 
