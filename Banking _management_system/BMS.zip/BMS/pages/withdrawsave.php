<html>
    <head>
        <style>
            nav{
                position:absolute;
                top:50px;
                left:10px;
                padding:10px;
                background-color:rgb(205, 235, 235);
                width:97%;
                height: 20px;
                border:2px black;
                border-radius:2px;
                box-shadow:0px 0px 2px 0px  ;
                color:rgb(22, 22, 23);
                margin-right:20px;
                
                

            }
            a{
                padding: 10px;
                margin-left: 20px;
                text-decoration: none;
                float:sticky;
            }

            a:hover{
                cursor: pointer;
                background-color:rgb(45, 43, 44);
                color:white;
                
            }
             
            a:active{
                margin-bottom:10px;
            }


            img{
                position:relative;
                top:30px;
            }
            .border{
                align-content:center;
                position:absolute;
                top:150px;
                left:450px;
                padding:20px;
                border: 4px green solid;
                border-radius: 5px;
                }
            input{
                border-radius: 5px;
            }
       </style>
    </head>
    <body>
        
        <h1><center><b> BMS BANK</b> </center></h1>
        
        <nav>
            <a href="usermain.html" >HOME</a> 
            <a href="Account.html" >Account</a> 
            <a href="Deposit.html">Deposit</a>
            <a href="withdraw.html">withdrawal</a>
            <a href="transactiondetails.php">Transactions</a>
            <div style="float: right;">
                <a  href="">logout</a>
            </div>
                </nav>
        <img src="OIP.jpg"  alt="bank " width="100%" height="100%" style="filter: blur(5px);" ></img>
        
        <div  class="border" >
    
            <form method="post" action="Accountsave.php">
                <h2 > <center>Withdrawed Successfully</center> </h2><hr>
                
           
                <?php
$accno = $_POST['accno'];
$withdraw = $_POST['withdraw'];
$con = new mysqli("localhost", "root", "", "bank");

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sql = "UPDATE accounts SET balance = balance - '$withdraw' WHERE accno = '$accno'";

if ($con->query($sql) === TRUE) {
    $sql = "INSERT INTO transactions (accno, transaction_type, amount, Balance) VALUES ('$accno', 'Withdraw', '$withdraw', (SELECT balance FROM accounts WHERE accno = '$accno'))";
    if ($con->query($sql) === TRUE) {
        echo "<br><center><b>Amount: &nbsp $withdraw &nbsp Debited!</b></center>";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();
?>

            






    </body>
</html> 
 





















 
 
